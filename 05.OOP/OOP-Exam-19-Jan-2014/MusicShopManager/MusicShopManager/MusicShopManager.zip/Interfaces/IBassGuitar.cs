﻿namespace MusicShopManager.Interfaces
{
    using System;
    using MusicShopManager.Interfaces;

    public interface IBassGuitar : IGuitar
    {
    }
}